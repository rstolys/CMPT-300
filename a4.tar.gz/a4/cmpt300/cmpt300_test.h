asmlinkage ling sys_cmpt300_test(int arg);
